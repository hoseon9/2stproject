
## 실습 환경 셋팅 

### 1. Chrome 설치 

https://www.google.com/intl/ko/chrome/

설치 후, 메인 브라우저로 설정해야 함!

### 2. Anaconda 설치

https://www.anaconda.com/products/individual

### 3. 주피터 노트북 실행하기 

윈도우즈에서 실행 방법 : https://bit.ly/38y43hK

- 맥(Mac)이나 리눅스인 경우 : 위 참고 파일에서 anaconda prompt 대신, terminal 에서 실행하면 됩니다.

----

### 4. 7주차 개발 환경 (이건 나중에 합니다!)
- 구글 코랩 환경 셋팅 : https://vision-ai.tistory.com/entry/%EA%B5%AC%EA%B8%80-Colab-%EC%9D%84-%EC%9D%B4%EC%9A%A9%ED%95%9C-%ED%8C%8C%EC%9D%B4%EC%8D%AC-%EA%B0%9C%EB%B0%9C-%ED%99%98%EA%B2%BD-%EC%84%A4%EC%A0%95


----

## 파이썬 데이터분석

- 본 강의는 파이썬 문법과 데이터분석 방법을 배웁니다. 

- 강의 소개 :  https://docs.google.com/presentation/d/1vYjZi4la4uSb0ZU6kFPf_4ymzrDJR4nRk12bIu_Tdew/edit?usp=sharing

- 실습파일은 매주, 아래 실습 환경 셋팅의 3번 실행방법 대로 하면 됩니다. 

- 질문은 이메일  blockenters@gmail.com 으로 받습니다. 질문의 답변은 수업시간에 해드립니다. 

- 파이썬 공부 무료 참고 교재 : https://drive.google.com/file/d/1GVam7eLAtbW0_oxBvsIaJ1ll4a5YqTA-/view?usp=sharing

- data1 : https://drive.google.com/file/d/1MpC_aPXEe6FTVGZawWganru21fRY8TWU/view?usp=sharing

- data2 : https://drive.google.com/file/d/1O9eE0MHemOK69vRCLc-ETo_fQI7GCVNM/view?usp=sharing

- 불용어 : https://vision-ai.tistory.com/entry/Stopwords-%EB%B6%88%EC%9A%A9%EC%96%B4

- 시카고 범죄 데이터 1  : https://drive.google.com/file/d/1fE0ThvIrHLn2_y-L-4AD5Ggpt0bU5F1A/view?usp=sharing

- 시카고 범죄 데이터 2 : https://drive.google.com/file/d/1wo4zY9mz8XzsF7H7OWUAhUrNlKI98xPX/view?usp=sharing

- 시카고 범죄 데이터 3 : https://drive.google.com/file/d/11t2RWb8pRidwDPk5u21GCGEWzLK2tNmG/view?usp=sharing

- 인공지능을 배포하는 방법 : https://vision-ai.tistory.com/entry/%ED%85%90%EC%84%9C%ED%94%8C%EB%A1%9C%EC%9A%B0%EC%9D%98-%EB%AA%A8%EB%8D%B8-weight%EA%B0%80%EC%A4%91%EC%B9%98-%EC%A0%80%EC%9E%A5%ED%95%98%EA%B3%A0-%EB%B6%88%EB%9F%AC%EC%98%A4%EA%B8%B0

----

sample_data = ['This is the first document.', 'I loved them', 'This document is the second document', 
               'I am loving you', 'And this is the third one.']
               
               
               
def message_cleaning(sentence) :
  Test_punc_removed = [  char for char in sentence if char not in string.punctuation ]
  Test_punc_removed_join = ''.join(Test_punc_removed)

  Test_punc_removed_join_clean = [ word for word in Test_punc_removed_join.split() if word.lower() not in stopwords_list ]
  return Test_punc_removed_join_clean





for i in range(len(myRatings)) : 
  movie_title = myRatings['Movie Name'][i]
  similiar_movie = movie_correlation[movie_title].dropna().sort_values(ascending=False).to_frame()
  similiar_movie.columns = ['Correlation']
  similiar_movie['Weight'] = myRatings['Ratings'][i] * similiar_movie['Correlation']
  similar_movies_list.append(similiar_movie)
